package pack.tests.reflects.counter;

public class Countee {
    public int cpuli = 0;
    protected int cprot = 0;
    int cpackp = 1;
    private int cpriv = 0;

    public void mpuli() {
    }

    public void mprot() {
    }

    public void mpackp() {
    }

    public void mpriv() {
    }
}
