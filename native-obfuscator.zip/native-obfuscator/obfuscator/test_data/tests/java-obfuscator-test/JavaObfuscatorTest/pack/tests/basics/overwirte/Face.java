package pack.tests.basics.overwirte;

public interface Face {
    String face(int i);
}
