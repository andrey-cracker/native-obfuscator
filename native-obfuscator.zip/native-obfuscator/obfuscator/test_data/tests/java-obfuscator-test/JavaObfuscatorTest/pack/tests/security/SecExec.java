package pack.tests.security;

public class SecExec {
    private static void doShutdown() {
        System.exit(-1);
    }
}
