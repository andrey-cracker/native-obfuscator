package pack.tests.basics.overwirte;

public abstract class Super implements Face {
    public void run() {
        System.out.println("FAIL");
    }
}
