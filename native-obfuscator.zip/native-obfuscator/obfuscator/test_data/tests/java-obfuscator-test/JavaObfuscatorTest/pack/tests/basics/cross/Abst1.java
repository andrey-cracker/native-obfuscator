package pack.tests.basics.cross;

public abstract class Abst1 {
    public abstract int add(int a, int b);

    public int mul(int a, int b) {
        return a * b;
    }
}
