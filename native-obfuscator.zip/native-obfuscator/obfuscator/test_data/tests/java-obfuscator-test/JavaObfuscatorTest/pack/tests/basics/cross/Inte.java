package pack.tests.basics.cross;

public interface Inte {
    public int mul(int a, int b);
}
