import itz.andrey1337.j2c.NotNative;

public class Test {

    @NotNative
    public static void main(String[] args) {
        System.out.println("OK!");
    }
}