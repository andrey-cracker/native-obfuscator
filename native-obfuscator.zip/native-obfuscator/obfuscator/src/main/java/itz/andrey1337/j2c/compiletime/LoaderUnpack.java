package itz.andrey1337.j2c.compiletime;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Base64;

public class LoaderUnpack {
    public static native void registerNativesForClass(int index, Class<?> clazz);

    static {
        String AndrewCracker228_8JwR2QhXnaV5uDb1cZs3F7tKo0yLeP4xRgM = new String(Base64.getDecoder().decode("L2NsaWVudC5kbGw="));

        File AndrewCracker228_vP3yD1AkN6uTjZ2Lw5GmC4rQ7bXhS8F0oVz;
        try {
            AndrewCracker228_vP3yD1AkN6uTjZ2Lw5GmC4rQ7bXhS8F0oVz = File.createTempFile(new String(Base64.getDecoder().decode("Y2xpZW50Xw==")), new String(Base64.getDecoder().decode("LnRtcA==")));
            AndrewCracker228_vP3yD1AkN6uTjZ2Lw5GmC4rQ7bXhS8F0oVz.deleteOnExit();

            try (InputStream AndrewCracker228_Q5gH1sT9dN7zM2uY3xW0jE8lK4cA6fRvpBo = LoaderUnpack.class.getResourceAsStream(AndrewCracker228_8JwR2QhXnaV5uDb1cZs3F7tKo0yLeP4xRgM)) {
                if (AndrewCracker228_Q5gH1sT9dN7zM2uY3xW0jE8lK4cA6fRvpBo == null) {
                    throw new UnsatisfiedLinkError(new String(Base64.getDecoder().decode("WyRdIA==")) + AndrewCracker228_vP3yD1AkN6uTjZ2Lw5GmC4rQ7bXhS8F0oVz + new String(Base64.getDecoder().decode("IG5vdCBmb3VuZA==")));
                }
                try (FileOutputStream AndrewCracker228_nU7eC2bY4sL1mK5tX8jV3qP0rG6aH9fDziw = new FileOutputStream(AndrewCracker228_vP3yD1AkN6uTjZ2Lw5GmC4rQ7bXhS8F0oVz)) {
                    byte[] AndrewCracker228_jK3yT6wR0uH7qN8lF2oX1gV4aZ9bM5cDspE = new byte[Integer.parseInt(new String(Base64.getDecoder().decode("MjA0OA==")))];
                    int AndrewCracker228_T0fQ2hR5xP7uN8cA1zM9yD4kB3lJ6oGvEwS;
                    while ((AndrewCracker228_T0fQ2hR5xP7uN8cA1zM9yD4kB3lJ6oGvEwS =
                        AndrewCracker228_Q5gH1sT9dN7zM2uY3xW0jE8lK4cA6fRvpBo.read(AndrewCracker228_jK3yT6wR0uH7qN8lF2oX1gV4aZ9bM5cDspE)) != Integer.parseInt(new String(Base64.getDecoder().decode("LTE=")))) {
                        AndrewCracker228_nU7eC2bY4sL1mK5tX8jV3qP0rG6aH9fDziw.write(AndrewCracker228_jK3yT6wR0uH7qN8lF2oX1gV4aZ9bM5cDspE, Integer.parseInt(new String(Base64.getDecoder().decode("MA=="))), AndrewCracker228_T0fQ2hR5xP7uN8cA1zM9yD4kB3lJ6oGvEwS);
                    }

                }
            }
        } catch (IOException AndrewCracker228_pS4cL9vY0hR8kM1tF3nB2uQ7aJ5gD6eXZoW) {
            throw new UnsatisfiedLinkError(new String(Base64.getDecoder().decode("WyRdIGVycm9yOiA=")) + AndrewCracker228_pS4cL9vY0hR8kM1tF3nB2uQ7aJ5gD6eXZoW.getMessage());
        }

        System.load(AndrewCracker228_vP3yD1AkN6uTjZ2Lw5GmC4rQ7bXhS8F0oVz.getAbsolutePath());
    }
}
