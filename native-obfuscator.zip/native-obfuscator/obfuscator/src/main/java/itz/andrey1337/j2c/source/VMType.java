package itz.andrey1337.j2c.source;

public enum VMType {
    HOTSPOT,
    STD_JAVA,
    ANDROID
}
