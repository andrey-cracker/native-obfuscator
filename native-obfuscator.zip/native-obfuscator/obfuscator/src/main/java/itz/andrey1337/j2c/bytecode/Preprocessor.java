package itz.andrey1337.j2c.bytecode;

import itz.andrey1337.j2c.source.VMType;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.MethodNode;

public interface Preprocessor {

    void process(ClassNode classNode, MethodNode methodNode, VMType platform);
}
