#ifndef STRING_POOL_HPP_GUARD

#define STRING_POOL_HPP_GUARD

namespace native_jvm::string_pool {
    char *get_pool();
}

#endif